;;; elpa-mirror-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "elpa-mirror" "elpa-mirror.el" (0 0 0 0))
;;; Generated autoloads from elpa-mirror.el

(autoload 'elpamr-version "elpa-mirror" "\
Current version.\n\n(fn)" t nil)

(autoload 'elpamr-create-mirror-for-installed "elpa-mirror" "\
Export INSTALLED packages into a new directory.\nCreate the html files for the mirror site.\n\nThe first valid directory found from the below list\nwill be used as mirror package's output directory:\n1. Argument: OUTPUT-DIRECTORY\n2. Variable: `elpamr-default-output-directory'\n3. Ask user to provide.\n\nWhen RECREATE-DIRECTORY is non-nil, OUTPUT-DIRECTORY\nwill be deleted and recreated.\n\n(fn &optional OUTPUT-DIRECTORY RECREATE-DIRECTORY)" t nil)

(if (fboundp 'register-definition-prefixes) (register-definition-prefixes "elpa-mirror" '("elpamr-")))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; elpa-mirror-autoloads.el ends here
