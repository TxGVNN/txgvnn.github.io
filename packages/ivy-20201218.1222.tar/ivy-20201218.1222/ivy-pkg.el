(define-package "ivy" "20201218.1222" "Incremental Vertical completYon"
  '((emacs "24.5"))
  :commit "77748673d3481f9fd1de91283c57ce535404c28f" :keywords
  '("matching")
  :authors
  '(("Oleh Krehel" . "ohwoeowho@gmail.com"))
  :maintainer
  '("Oleh Krehel" . "ohwoeowho@gmail.com")
  :url "https://github.com/abo-abo/swiper")
;; Local Variables:
;; no-byte-compile: t
;; End:
