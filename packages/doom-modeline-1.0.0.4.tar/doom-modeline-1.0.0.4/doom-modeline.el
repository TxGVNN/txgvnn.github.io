;;; doom-modeline.el --- A minimal and modern modeline -*- lexical-binding: t; -*-

;; Copyright (C) 2018 Vincent Zhang

;; Author: Vincent Zhang <seagle0128@gmail.com>
;; Homepage: https://github.com/seagle0128/doom-modeline
;; Version: 1.0.0.4
;; Based: @2e65c9d06b30cef156f7e74b773e67b487af9b24
;; Package-Requires: ((emacs "25.1") (shrink-path "0.2.0") (dash "2.11.0"))
;; Keywords: faces mode-line
;;
(require 'shrink-path)
(require 'subr-x)
(when (>= emacs-major-version 26)
  (require 'project))

;;
;; Variables
;;

(defvar doom-modeline-height 25
  "How tall the mode-line should be (only respected in GUI Emacs).")

(defvar doom-modeline-bar-width 3
  "How wide the mode-line bar should be (only respected in GUI Emacs).")

(defvar doom-modeline-buffer-file-name-style 'truncate-with-project)


(defvar doom-modeline-icon (display-graphic-p))

(defvar doom-modeline-major-mode-icon t
  "Whether show the icon for major mode. It should respect `doom-modeline-icon'.")

(defvar doom-modeline-minor-modes nil
  "Whether display minor modes or not. Non-nil to display in mode-line.")

(defvar doom-modeline-persp-name t
  "Whether display perspective name or not. Non-nil to display in mode-line.")

(defvar doom-modeline-lsp t
  "Whether display `lsp' state or not. Non-nil to display in mode-line.")


;;
;; Compatibilities
;;

(unless (>= emacs-major-version 26)
  (with-no-warnings
    ;; Define `if-let*' and `when-let*' variants for 25 users.
    (defalias 'if-let* #'if-let)
    (defalias 'when-let* #'when-let)))

;; Don’t compact font caches during GC.
(if (eq system-type 'windows-nt)
    (setq inhibit-compacting-font-caches t))

;;`file-local-name' is introduced in 25.2.2.
(unless (fboundp 'file-local-name)
  (defun file-local-name (file)
    "Return the local name component of FILE.
It returns a file name which can be used directly as argument of
`process-file', `start-file-process', or `shell-command'."
    (or (file-remote-p file 'localname) file)))

;; Don’t compact font caches during GC.
(if (eq system-type 'windows-nt)
    (setq inhibit-compacting-font-caches t))

;;`file-local-name' is introduced in 25.2.2.
(unless (fboundp 'file-local-name)
  (defun file-local-name (file)
    "Return the local name component of FILE.
It returns a file name which can be used directly as argument of
`process-file', `start-file-process', or `shell-command'."
    (or (file-remote-p file 'localname) file)))

;;
;; externals
;;

(defvar anzu--current-position)
(defvar anzu--overflow-p)
(defvar anzu--state)
(defvar anzu--total-matched)
(defvar anzu-cons-mode-line-p)
(defvar flycheck-current-errors)
(defvar flycheck-mode-menu-map)
(defvar flymake--backend-state)
(defvar flymake--mode-line-format)
(defvar flymake-menu)
(defvar mc/mode-line)
(defvar minions-mode)
(defvar minions-mode-line-lighter)
(defvar persp-nil-name)
(defvar text-scale-mode-amount)

(declare-function anzu--reset-status 'anzu)
(declare-function anzu--where-is-here 'anzu)
(declare-function eyebrowse--get 'eyebrowse)
(declare-function face-remap-remove-relative 'face-remap)
(declare-function flycheck-count-errors 'flycheck)
(declare-function flycheck-list-errors 'flycheck)
(declare-function image-get-display-property 'image-mode)
(declare-function lsp-mode-line 'lsp-mode)
(declare-function magit-toplevel 'magit-git)
(declare-function safe-persp-name 'persp-mode)
(declare-function get-current-persp 'persp-mode)
(declare-function persp-contain-buffer-p 'persp-mode)
(declare-function persp-add-buffer 'persp-mode)
(declare-function persp-remove-buffer 'persp-mode)
(declare-function persp-switch 'persp-mode)
(declare-function project-current 'project)
(declare-function project-roots 'project)
(declare-function projectile-project-root 'projectile)

;;
;; Custom faces
;;

(defgroup doom-modeline nil
  "Doom mode-line faces."
  :group 'faces)

(defface doom-modeline-buffer-path
  '((t (:inherit (mode-line-emphasis bold))))
  "Face used for the dirname part of the buffer path.")

(defface doom-modeline-buffer-file
  '((t (:inherit (mode-line-buffer-id bold))))
  "Face used for the filename part of the mode-line buffer path.")

(defface doom-modeline-buffer-modified
  '((t (:inherit (error bold) :background nil)))
  "Face used for the 'unsaved' symbol in the mode-line.")

(defface doom-modeline-buffer-major-mode
  '((t (:inherit (mode-line-emphasis bold))))
  "Face used for the major-mode segment in the mode-line.")

(defface doom-modeline-buffer-minor-mode
  '((t (:inherit (mode-line-buffer-id bold))))
  "Face used for the minor-modes segment in the mode-line.")

(defface doom-modeline-project-root-dir
  '((t (:inherit (mode-line-emphasis bold))))
  "Face used for the project part of the mode-line buffer path.")

(defface doom-modeline-highlight
  '((t (:inherit mode-line-emphasis)))
  "Face for bright segments of the mode-line.")

(defface doom-modeline-panel
  '((t (:inherit mode-line-highlight)))
  "Face for 'X out of Y' segments, such as `doom-modeline--anzu'")

(defface doom-modeline-info
  `((t (:inherit (success bold))))
  "Face for info-level messages in the modeline. Used by `*vc'.")

(defface doom-modeline-warning
  `((t (:inherit (warning bold))))
  "Face for warnings in the modeline. Used by `*flycheck'")

(defface doom-modeline-urgent
  `((t (:inherit (error bold))))
  "Face for errors in the modeline. Used by `*flycheck'")

;; Bar
(defface doom-modeline-bar '((t (:inherit highlight)))
  "The face used for the left-most bar on the mode-line of an active window.")

(defface doom-modeline-inactive-bar `((t (:background
                                          ,(face-foreground 'mode-line-inactive)
                                          :foreground
                                          ,(face-background 'mode-line-inactive))))
  "The face used for the left-most bar on the mode-line of an inactive window.")


(defface doom-modeline-persp-name '((t (:inherit font-lock-comment-face :italic t)))
  "Face for the replace state tag in evil state indicator.")

(defface doom-modeline-persp-buffer-not-in-persp '((t (:inherit font-lock-doc-face :bold t)))
  "Face for the replace state tag in evil state indicator.")

;;
;; Modeline library
;;

(eval-and-compile
  (defvar doom-modeline-fn-alist ())
  (defvar doom-modeline-var-alist ()))

(defmacro doom-modeline-def-segment (name &rest body)
  "Defines a modeline segment NAME with BODY and byte compiles it."
  (declare (indent defun) (doc-string 2))
  (let ((sym (intern (format "doom-modeline-segment--%s" name)))
        (docstring (if (stringp (car body))
                       (pop body)
                     (format "%s modeline segment" name))))
    (cond ((and (symbolp (car body))
                (not (cdr body)))
           (add-to-list 'doom-modeline-var-alist (cons name (car body)))
           `(add-to-list 'doom-modeline-var-alist (cons ',name ',(car body))))
          (t
           (add-to-list 'doom-modeline-fn-alist (cons name sym))
           `(progn
              (fset ',sym (lambda () ,docstring ,@body))
              (add-to-list 'doom-modeline-fn-alist (cons ',name ',sym))
              ,(unless (bound-and-true-p byte-compile-current-file)
                 `(let (byte-compile-warnings)
                    (byte-compile #',sym))))))))

(defun doom-modeline--prepare-segments (segments)
  "Prepare mode-line `SEGMENTS'."
  (let (forms it)
    (dolist (seg segments)
      (cond ((stringp seg)
             (push seg forms))
            ((symbolp seg)
             (cond ((setq it (cdr (assq seg doom-modeline-fn-alist)))
                    (push (list :eval (list it)) forms))
                   ((setq it (cdr (assq seg doom-modeline-var-alist)))
                    (push it forms))
                   ((error "%s is not a defined segment" seg))))
            ((error "%s is not a valid segment" seg))))
    (nreverse forms)))

(defun doom-modeline-def-modeline (name lhs &optional rhs)
  "Defines a modeline format and byte-compiles it.
NAME is a symbol to identify it (used by `doom-modeline' for retrieval).
LHS and RHS are lists of symbols of modeline segments defined with
`doom-modeline-def-segment'.

Example:
  (doom-modeline-def-modeline 'minimal
     '(bar matches \" \" buffer-info)
     '(media-info major-mode))
  (doom-modeline-set-modeline 'minimal t)"
  (let ((sym (intern (format "doom-modeline-format--%s" name)))
        (lhs-forms (doom-modeline--prepare-segments lhs))
        (rhs-forms (doom-modeline--prepare-segments rhs)))
    (defalias sym
      (lambda ()
        (let ((rhs-str (format-mode-line (cons "" rhs-forms))))
          (list lhs-forms
                (propertize
                 " " 'display
                 `((space :align-to (- (+ right right-fringe right-margin)
                                       ,(+ 1 (string-width rhs-str))))))
                rhs-str)))
      (concat "Modeline:\n"
              (format "  %s\n  %s"
                      (prin1-to-string lhs)
                      (prin1-to-string rhs))))))
(put 'doom-modeline-def-modeline 'lisp-indent-function 'defun)

(defun doom-modeline (key)
  "Return a mode-line configuration associated with KEY (a symbol).
Throws an error if it doesn't exist."
  (let ((fn (intern-soft (format "doom-modeline-format--%s" key))))
    (when (functionp fn)
      `(:eval (,fn)))))

(defun doom-modeline-set-modeline (key &optional default)
  "Set the modeline format. Does nothing if the modeline KEY doesn't exist.
If DEFAULT is non-nil, set the default mode-line for all buffers."
  (when-let ((modeline (doom-modeline key)))
    (setf (if default
              (default-value 'mode-line-format)
            (buffer-local-value 'mode-line-format (current-buffer)))
          (list "%e" modeline))))

(defvar-local doom-modeline-project-root nil)
(defun doom-modeline-project-root ()
  "Get the path to the root of your project.

  Return `default-directory' if no project was found."
  (or doom-modeline-project-root
      (setq doom-modeline-project-root
            (file-local-name
             (or
              (when (featurep 'projectile)
                (ignore-errors (projectile-project-root)))
              (when (featurep 'project)
                (ignore-errors
                  (when-let ((project (project-current)))
                    (expand-file-name (car (project-roots project))))))
              default-directory)))))


;; anzu expose current/total state that can be displayed in the
;; mode-line.
(defun doom-modeline-fix-anzu-count (positions here)
  "Calulate anzu counts via POSITIONS and HERE."
  (cl-loop for (start . end) in positions
           collect t into before
           when (and (>= here start) (<= here end))
           return (length before)
           finally return 0))

(advice-add #'anzu--where-is-here :override #'doom-modeline-fix-anzu-count)

;; Avoid anzu conflicts across buffers
;; (mapc #'make-variable-buffer-local
;;       '(anzu--total-matched anzu--current-position anzu--state
;;                             anzu--cached-count anzu--cached-positions anzu--last-command
;;                             anzu--last-isearch-string anzu--overflow-p))

;; Ensure anzu state is cleared when searches & iedit are done
(with-eval-after-load 'anzu
  (add-hook 'isearch-mode-end-hook #'anzu--reset-status t))

;; Keep `doom-modeline-current-window' up-to-date
(defvar doom-modeline-current-window (frame-selected-window))
(defun doom-modeline-set-selected-window (&rest _)
  "Set `doom-modeline-current-window' appropriately."
  (when-let ((win (frame-selected-window)))
    (unless (minibuffer-window-active-p win)
      (setq doom-modeline-current-window win)
      (force-mode-line-update))))

(defun doom-modeline-unset-selected-window ()
  "Unset `doom-modeline-current-window' appropriately."
  (setq doom-modeline-current-window nil)
  (force-mode-line-update))

(add-hook 'window-configuration-change-hook #'doom-modeline-set-selected-window)
(advice-add #'handle-switch-frame :after #'doom-modeline-set-selected-window)
(advice-add #'select-window :after #'doom-modeline-set-selected-window)
(advice-add #'make-frame :after #'doom-modeline-set-selected-window)
(advice-add #'delete-frame :after #'doom-modeline-set-selected-window)
(with-no-warnings
  (cond ((not (boundp 'after-focus-change-function))
         (add-hook 'focus-in-hook  #'doom-modeline-set-selected-window)
         (add-hook 'focus-out-hook #'doom-modeline-unset-selected-window))
        ((defun doom-modeline-refresh-frame ()
           (setq doom-modeline-current-window nil)
           (cl-loop for frame in (frame-list)
                    if (eq (frame-focus-state frame) t)
                    return (setq doom-modeline-current-window (frame-selected-window frame)))
           (force-mode-line-update))
         (add-function :after after-focus-change-function #'doom-modeline-refresh-frame))))

;;
;; Modeline helpers
;;

(defvar doom-modeline-vspc
  (propertize " " 'face 'variable-pitch)
  "Text style with icons in mode-line.")

(defun doom-modeline-icon-show (&rest args)
  "Display octicon via ARGS."
  (concat ""))

(defun doom-modeline--active ()
  "Whether is an active window."
  (eq (selected-window) doom-modeline-current-window))

(defun doom-modeline--make-xpm (face width height)
  "Create an XPM bitmap via FACE, WIDTH and HEIGHT. Inspired by `powerline''s `pl/make-xpm'."
  (propertize
   " " 'display
   (let ((data (make-list height (make-list width 1)))
         (color (or (face-background face nil t) "None")))
     (ignore-errors
       (create-image
        (concat
         (format "/* XPM */\nstatic char * percent[] = {\n\"%i %i 2 1\",\n\". c %s\",\n\"  c %s\","
                 (length (car data))
                 (length data)
                 color
                 color)
         (apply #'concat
                (cl-loop with idx = 0
                         with len = (length data)
                         for dl in data
                         do (cl-incf idx)
                         collect
                         (concat "\""
                                 (cl-loop for d in dl
                                          if (= d 0) collect (string-to-char " ")
                                          else collect (string-to-char "."))
                                 (if (eq idx len) "\"};" "\",\n")))))
        'xpm t :ascent 'center)))))

(defun doom-modeline-buffer-file-name ()
  "Propertized variable `buffer-file-name' based on `doom-modeline-buffer-file-name-style'."
  (let* ((buffer-file-name (file-local-name (or (buffer-file-name (buffer-base-buffer)) "")))
         (buffer-file-truename (file-local-name (or buffer-file-truename (file-truename buffer-file-name) ""))))
    (propertize
     (pcase doom-modeline-buffer-file-name-style
       (`truncate-upto-project
        (doom-modeline--buffer-file-name buffer-file-name buffer-file-truename 'shrink))
       (`truncate-from-project
        (doom-modeline--buffer-file-name buffer-file-name buffer-file-truename nil 'shrink))
       (`truncate-with-project
        (doom-modeline--buffer-file-name buffer-file-truename buffer-file-name 'shrink 'shink 'hide))
       (`truncate-except-project
        (doom-modeline--buffer-file-name buffer-file-name buffer-file-truename 'shrink 'shink))
       (`truncate-upto-root
        (doom-modeline--buffer-file-name-truncate buffer-file-name buffer-file-truename))
       (`truncate-all
        (doom-modeline--buffer-file-name-truncate buffer-file-name buffer-file-truename t))
       (`relative-to-project
        (doom-modeline--buffer-file-name-relative buffer-file-name buffer-file-truename))
       (`relative-from-project
        (doom-modeline--buffer-file-name-relative buffer-file-name buffer-file-truename 'include-project))
       (style
        (propertize
         (pcase style
           (`file-name (file-name-nondirectory buffer-file-name))
           (`buffer-name (buffer-name)))
         'face
         (let ((face (or (and (buffer-modified-p)
                              'doom-modeline-buffer-modified)
                         (and (doom-modeline--active)
                              'doom-modeline-buffer-file))))
           (when face `(:inherit ,face))))))
     'local-map mode-line-buffer-identification-keymap)))

(defun doom-modeline--buffer-file-name-truncate (file-path true-file-path &optional truncate-tail)
  "Propertized variable `buffer-file-name' that truncates every dir along path.
If TRUNCATE-TAIL is t also truncate the parent directory of the file."
  (let ((dirs (shrink-path-prompt (file-name-directory true-file-path)))
        (active (doom-modeline--active)))
    (if (null dirs)
        (propertize "%b" 'face (if active 'doom-modeline-buffer-file))
      (let ((modified-faces (if (buffer-modified-p) 'doom-modeline-buffer-modified)))
        (let ((dirname (car dirs))
              (basename (cdr dirs))
              (dir-faces (or modified-faces (if active 'doom-modeline-project-root-dir)))
              (file-faces (or modified-faces (if active 'doom-modeline-buffer-file))))
          (concat (propertize (concat dirname
                                      (if truncate-tail (substring basename 0 1) basename)
                                      "/")
                              'face (if dir-faces `(:inherit ,dir-faces)))
                  (propertize (file-name-nondirectory file-path)
                              'face (if file-faces `(:inherit ,file-faces)))))))))

(defun doom-modeline--buffer-file-name-relative (_file-path true-file-path &optional include-project)
  "Propertized variable `buffer-file-name' showing directories relative to project's root only."
  (let ((root (doom-modeline-project-root))
        (active (doom-modeline--active)))
    (if (null root)
        (propertize "%b" 'face (if active 'doom-modeline-buffer-file))
      (let* ((modified-faces (if (buffer-modified-p) 'doom-modeline-buffer-modified))
             (relative-dirs (file-relative-name (file-name-directory true-file-path)
                                                (if include-project (concat root "../") root)))
             (relative-faces (or modified-faces (if active 'doom-modeline-buffer-path)))
             (file-faces (or modified-faces (if active 'doom-modeline-buffer-file))))
        (if (equal "./" relative-dirs) (setq relative-dirs ""))
        (concat (propertize relative-dirs 'face (if relative-faces `(:inherit ,relative-faces)))
                (propertize (file-name-nondirectory true-file-path)
                            'face (if file-faces `(:inherit ,file-faces))))))))

(defun doom-modeline--buffer-file-name (file-path _true-file-path &optional truncate-project-root-parent truncate-project-relative-path hide-project-root-parent)
  "Propertized variable `buffer-file-name' given by FILE-PATH.
If TRUNCATE-PROJECT-ROOT-PARENT is non-nil will be saved by truncating project
root parent down fish-shell style.

Example:
  ~/Projects/FOSS/emacs/lisp/comint.el => ~/P/F/emacs/lisp/comint.el

If TRUNCATE-PROJECT-RELATIVE-PATH is non-nil will be saved by truncating project
relative path down fish-shell style.

Example:
  ~/Projects/FOSS/emacs/lisp/comint.el => ~/Projects/FOSS/emacs/l/comint.el

If HIDE-PROJECT-ROOT-PARENT is non-nil will hide project root parent.

Example:
  ~/Projects/FOSS/emacs/lisp/comint.el => emacs/lisp/comint.el"
  (let ((project-root (doom-modeline-project-root))
        (active (doom-modeline--active))
        (modified-faces (if (buffer-modified-p) 'doom-modeline-buffer-modified)))
    (let ((sp-faces       (or modified-faces (if active 'font-lock-comment-face)))
          (project-faces  (or modified-faces (if active 'font-lock-string-face)))
          (relative-faces (or modified-faces (if active 'doom-modeline-buffer-path)))
          (file-faces     (or modified-faces (if active 'doom-modeline-buffer-file))))
      (let ((sp-props       `(,@(if sp-faces       `(:inherit ,sp-faces))      ,@(if active '(:weight bold))))
            (project-props  `(,@(if project-faces  `(:inherit ,project-faces)) ,@(if active '(:weight bold))))
            (relative-props `(,@(if relative-faces `(:inherit ,relative-faces))))
            (file-props     `(,@(if file-faces     `(:inherit ,file-faces)))))
        (concat
         ;; project root parent
         (unless hide-project-root-parent
           (when-let (root-path-parent
                      (file-name-directory (directory-file-name project-root)))
             (propertize
              (if (and truncate-project-root-parent
                       (not (string-empty-p root-path-parent))
                       (not (string= root-path-parent "/")))
                  (shrink-path--dirs-internal root-path-parent t)
                (abbreviate-file-name root-path-parent))
              'face sp-props)))
         ;; project
         (propertize
          (concat (file-name-nondirectory (directory-file-name project-root)) "/")
          'face project-props)
         ;; relative path
         (propertize
          (when-let (relative-path (file-relative-name
                                    (or (file-name-directory file-path) "./")
                                    project-root))
            (if (string= relative-path "./")
                ""
              (if truncate-project-relative-path
                  (substring (shrink-path--dirs-internal relative-path t) 1)
                relative-path)))
          'face relative-props)
         ;; file name
         (propertize (file-name-nondirectory file-path) 'face file-props))))))


;;
;; buffer information
;;

(doom-modeline-def-segment buffer-default-directory
  "Displays `default-directory'. This is for special buffers like the scratch
buffer where knowing the current project directory is important."
  (let ((face (if (doom-modeline--active) 'doom-modeline-buffer-path)))
    (concat (if (display-graphic-p) " ")
            (propertize (concat " " (abbreviate-file-name default-directory))
                        'face face))))


(defvar-local doom-modeline--buffer-file-state-icon nil)
(defun doom-modeline-update-buffer-file-state-icon (&rest _)
  "Update the buffer or file state in mode-line."
  (setq doom-modeline--buffer-file-state-icon
        (let ((active (doom-modeline--active)))
          (cond (buffer-read-only
                 (propertize "R " 'face 'doom-modeline-warning))
                ((buffer-modified-p)
                 (propertize "M " 'face 'doom-modeline-buffer-modified))
                ((and buffer-file-name
                      (not (file-exists-p buffer-file-name)))
                 (propertize "* " 'face 'doom-modeline-urgent))
                ((buffer-narrowed-p)
                 (propertize "? " 'face 'doom-modeline-warning))))))

(add-hook 'find-file-hook #'doom-modeline-update-buffer-file-state-icon)
(add-hook 'after-save-hook #'doom-modeline-update-buffer-file-state-icon)
(add-hook 'after-revert-hook #'doom-modeline-update-buffer-file-state-icon)
(add-hook 'read-only-mode-hook #'doom-modeline-update-buffer-file-state-icon)
(add-hook 'after-change-functions #'doom-modeline-update-buffer-file-state-icon)
(add-hook 'clone-indirect-buffer-hook #'doom-modeline-update-buffer-file-state-icon)
(advice-add #'undo :after #'doom-modeline-update-buffer-file-state-icon)
(advice-add #'undo-tree-undo :after #'doom-modeline-update-buffer-file-state-icon)
(advice-add #'undo-tree-redo :after #'doom-modeline-update-buffer-file-state-icon)
(advice-add #'narrow-to-region :after #'doom-modeline-update-buffer-file-state-icon)
(advice-add #'widen :after #'doom-modeline-update-buffer-file-state-icon)

(when (>= emacs-major-version 26)
  (add-variable-watcher
   'buffer-read-only
   (lambda (_sym val op _where)
     (when (eq op 'set)
       (setq buffer-read-only val)
       (doom-modeline-update-buffer-file-state-icon)))))

(defvar-local doom-modeline--buffer-file-name nil)
(defun doom-modeline-update-buffer-file-name (&rest _)
  "Update buffer file name in mode-line."
  (setq doom-modeline--buffer-file-name
        (if buffer-file-name
            (doom-modeline-buffer-file-name)
          (propertize "%b"
                      'face (if (doom-modeline--active) 'doom-modeline-buffer-file)))))
(add-hook 'find-file-hook #'doom-modeline-update-buffer-file-name)
(add-hook 'after-save-hook #'doom-modeline-update-buffer-file-name)
(add-hook 'after-revert-hook #'doom-modeline-update-buffer-file-name)
(add-hook 'after-change-functions #'doom-modeline-update-buffer-file-name)
(add-hook 'clone-indirect-buffer-hook #'doom-modeline-update-buffer-file-name)
(advice-add #'rename-buffer :after #'doom-modeline-update-buffer-file-name)
(advice-add #'set-visited-file-name :after #'doom-modeline-update-buffer-file-name)
(advice-add #'undo :after #'doom-modeline-update-buffer-file-name)
(advice-add #'undo-tree-undo :after #'doom-modeline-update-buffer-file-name)
(advice-add #'undo-tree-redo :after #'doom-modeline-update-buffer-file-name)

(doom-modeline-def-segment buffer-info
  "Combined information about the current buffer, including the current working
directory, the file name, and its state (modified, read-only or non-existent)."
  (let ((active (doom-modeline--active)))
    (concat
     ;; state icon
     (if active
         (or doom-modeline--buffer-file-state-icon (doom-modeline-update-buffer-file-state-icon)))
     ;; buffer file name
     (let ((name (or doom-modeline--buffer-file-name
                     (doom-modeline-update-buffer-file-name))))
       (if active
           name
         (propertize name 'face 'mode-line-inactive))))))

(doom-modeline-def-segment buffer-info-simple
  "Display only the current buffer's name, but with fontification."
  (propertize
   "%b"
   'face (cond ((and buffer-file-name (buffer-modified-p))
                'doom-modeline-buffer-modified)
               ((doom-modeline--active) 'doom-modeline-buffer-file))))


(doom-modeline-def-segment buffer-encoding
  "Displays the encoding and eol style of the buffer the same way Atom does."
  (propertize
   (concat (pcase (coding-system-eol-type buffer-file-coding-system)
             (0 " LF")
             (1 " RLF")
             (2 " CR"))
           (let ((sys (coding-system-plist buffer-file-coding-system)))
             (cond ((memq (plist-get sys :category) '(coding-category-undecided coding-category-utf-8))
                    " UTF-8 ")
                   (t (upcase (symbol-name (plist-get sys :name))))))
           " ")))


;;
;; remote host
;;

(doom-modeline-def-segment remote-host
  "Hostname for remote buffers."
  (when default-directory
    (when-let ((host (file-remote-p default-directory 'host)))
      (concat "@" host))))

;;
;; major-mode
;;

(doom-modeline-def-segment major-mode
  "The major mode, including  text-scale info."
  (propertize
   (concat (format-mode-line
            `(:propertize ("" mode-name)))
           (and (boundp 'text-scale-mode-amount)
                (/= text-scale-mode-amount 0)
                (format
                 (if (> text-scale-mode-amount 0)
                     " (%+d)"
                   " (%-d)")
                 text-scale-mode-amount)))
   'face (if (doom-modeline--active) 'doom-modeline-buffer-major-mode)))

;;
;; process
;;

(doom-modeline-def-segment process
  "The process info."
  mode-line-process)


;;
;; minor modes
;;

(doom-modeline-def-segment minor-modes
  (when doom-modeline-minor-modes
    (let ((active (doom-modeline--active)))
      (if (bound-and-true-p minions-mode)
          (concat
           " "
           (propertize minions-mode-line-lighter
                       'face (if active 'doom-modeline-buffer-minor-mode))
           " ")
        (propertize
         (concat (format-mode-line `(:propertize ("" minor-mode-alist))) " ")
         'face (if active 'doom-modeline-buffer-minor-mode))))))

;;
;; vcs
;;

(defun doom-modeline-vcs-icon (icon &optional text face voffset)
  "Displays the vcs ICON with FACE and VOFFSET.
TEXT is the alternative if it is not applicable."
  (if text (propertize text 'face face) ""))

(defvar-local doom-modeline--vcs-icon nil)
(defun doom-modeline--update-vcs-icon (&rest _)
  "Update icon of vsc state in mode-line."
  (setq doom-modeline--vcs-icon
        (when (and vc-mode buffer-file-name)
          (let* ((backend (vc-backend buffer-file-name))
                 (state   (vc-state buffer-file-name backend)))
            (cond ((memq state '(edited added))
                   (doom-modeline-vcs-icon "git-compare" "*" 'doom-modeline-info -0.05))
                  ((eq state 'needs-merge)
                   (doom-modeline-vcs-icon "git-merge" "?" 'doom-modeline-info))
                  ((eq state 'needs-update)
                   (doom-modeline-vcs-icon "arrow-down" "!" 'doom-modeline-warning))
                  ((memq state '(removed conflict unregistered))
                   (doom-modeline-vcs-icon "alert" "!" 'doom-modeline-urgent))
                  (t
                   (doom-modeline-vcs-icon "git-branch" "@" 'doom-modeline-info -0.05)))))))
(add-hook 'after-revert-hook #'doom-modeline--update-vcs-icon)
(add-hook 'after-save-hook #'doom-modeline--update-vcs-icon)
(add-hook 'find-file-hook #'doom-modeline--update-vcs-icon t)
(advice-add #'vc-refresh-state :after #'doom-modeline--update-vcs-icon)

(defvar-local doom-modeline--vcs-text nil)
(defun doom-modeline--update-vcs-text (&rest _)
  "Update text of vsc state in mode-line."
  (setq doom-modeline--vcs-text
        (when (and vc-mode buffer-file-name)
          (let* ((backend (vc-backend buffer-file-name))
                 (state   (vc-state buffer-file-name backend)))
            (propertize (substring vc-mode (+ (if (eq backend 'Hg) 2 3) 2))
                        'face (cond ((eq state 'needs-update)
                                     'doom-modeline-warning)
                                    ((memq state '(removed conflict unregistered))
                                     'doom-modeline-urgent)
                                    (t 'doom-modeline-info)))))))
(add-hook 'after-revert-hook #'doom-modeline--update-vcs-text)
(add-hook 'after-save-hook #'doom-modeline--update-vcs-text)
(add-hook 'find-file-hook #'doom-modeline--update-vcs-text t)
(advice-add #'vc-refresh-state :after #'doom-modeline--update-vcs-text)

(doom-modeline-def-segment vcs
  "Displays the current branch, colored based on its state."
  (let ((active (doom-modeline--active)))
    (when-let ((icon (or doom-modeline--vcs-icon (doom-modeline--update-vcs-icon)))
               (text (or doom-modeline--vcs-text (doom-modeline--update-vcs-text))))
      (concat
       "  "
       (if active
           (concat icon text)
         (concat
          (propertize icon 'face 'mode-line-inactive)
          (propertize text 'face 'mode-line-inactive)))
       " "))))

;;
;; checker
;;

;; flycheck

(defun doom-modeline-checker-icon (icon &optional text face voffset)
  "Displays the checker ICON with FACE and VOFFSET.
TEXT is the alternative if it is not applicable."
  (if text
      (propertize text 'face face)
    ""))

(defun doom-modeline-checker-text (text &optional face)
  "Displays TEXT with FACE."
  (if text
      (propertize text 'face face)
    ""))

(defvar-local doom-modeline--flycheck-icon nil)
(defun doom-modeline-update-flycheck-icon (&optional status)
  "Update flycheck icon via STATUS."
  (setq doom-modeline--flycheck-icon
        (propertize
         (pcase status
           (`finished  (if flycheck-current-errors
                           (let-alist (flycheck-count-errors flycheck-current-errors)
                             (doom-modeline-checker-icon "do_not_disturb_alt" "!"
                                                         (cond (.error 'doom-modeline-urgent)
                                                               (.warning 'doom-modeline-warning)
                                                               (t 'doom-modeline-info))))
                         (doom-modeline-checker-icon "check" "*" 'doom-modeline-info)))
           (`running     (doom-modeline-checker-icon "access_time" "*" 'font-lock-doc-face))
           (`no-checker  (doom-modeline-checker-icon "sim_card_alert" "?" 'font-lock-doc-face))
           (`errored     (doom-modeline-checker-icon "sim_card_alert" "!" 'doom-modeline-urgent))
           (`interrupted (doom-modeline-checker-icon "pause" "!" 'font-lock-doc-face))
           (`suspicious  (doom-modeline-checker-icon "priority_high" "!" 'doom-modeline-urgent))
           (_ "")))))
(add-hook 'flycheck-status-changed-functions #'doom-modeline-update-flycheck-icon)
(add-hook 'flycheck-mode-hook #'doom-modeline-update-flycheck-icon)

(defvar-local doom-modeline--flycheck-text nil)
(defun doom-modeline-update-flycheck-text (&optional status)
  "Update flycheck text via STATUS."
  (setq doom-modeline--flycheck-text
        (propertize
         (pcase status
           (`finished  (if flycheck-current-errors
                           (let-alist (flycheck-count-errors flycheck-current-errors)
                             (let ((error (or .error 0))
                                   (warning (or .warning 0))
                                   (info (or .info 0)))
                               (format "%s/%s/%s"
                                       (doom-modeline-checker-text (number-to-string error)
                                                                   'doom-modeline-urgent)
                                       (doom-modeline-checker-text (number-to-string warning)
                                                                   'doom-modeline-warning)
                                       (doom-modeline-checker-text (number-to-string info)
                                                                   'doom-modeline-info))))
                         ""))
           (`running     "")
           (`no-checker  (doom-modeline-checker-text "-" 'font-lock-doc-face))
           (`errored     (doom-modeline-checker-text "Error" 'doom-modeline-urgent))
           (`interrupted (doom-modeline-checker-text "Interrupted" 'font-lock-doc-face))
           (`suspicious  (doom-modeline-checker-text "Suspicious" 'doom-modeline-urgent))
           (_ "")))))
(add-hook 'flycheck-status-changed-functions #'doom-modeline-update-flycheck-text)
(add-hook 'flycheck-mode-hook #'doom-modeline-update-flycheck-text)

;; flymake

(defvar-local doom-modeline--flymake-icon nil)
(defun doom-modeline-update-flymake-icon (&rest _)
  "Update flymake icon."
  (setq flymake--mode-line-format nil) ; remove the lighter of minor mode
  (setq doom-modeline--flymake-icon
        (let* ((known (hash-table-keys flymake--backend-state))
               (running (flymake-running-backends))
               (disabled (flymake-disabled-backends))
               (reported (flymake-reporting-backends))
               (diags-by-type (make-hash-table))
               (all-disabled (and disabled (null running)))
               (some-waiting (cl-set-difference running reported)))
          (maphash (lambda (_b state)
                     (mapc (lambda (diag)
                             (push diag
                                   (gethash (flymake--diag-type diag)
                                            diags-by-type)))
                           (flymake--backend-state-diags state)))
                   flymake--backend-state)
          (propertize
           (cond
            (some-waiting (doom-modeline-checker-icon "access_time" "*" 'font-lock-doc-face))
            ((null known) (doom-modeline-checker-icon "sim_card_alert" "?" 'font-lock-doc-face))
            (all-disabled (doom-modeline-checker-icon "sim_card_alert" "!" 'doom-modeline-urgent))
            (t (let ((.error (length (gethash :error diags-by-type)))
                     (.warning (length (gethash :warning diags-by-type)))
                     (.note (length (gethash :note diags-by-type))))
                 (if (> (+ .error .warning .note) 0)
                     (doom-modeline-checker-icon "do_not_disturb_alt" "!"
                                                 (cond ((> .error 0) 'doom-modeline-urgent)
                                                       ((> .warning 0) 'doom-modeline-warning)
                                                       (t 'doom-modeline-info)))
                   (doom-modeline-checker-icon "check" "*" 'doom-modeline-info)))))))))

(advice-add #'flymake--handle-report :after #'doom-modeline-update-flymake-icon)

(defvar-local doom-modeline--flymake-text nil)
(defun doom-modeline-update-flymake-text (&rest _)
  "Update flymake text."
  (setq flymake--mode-line-format nil) ; remove the lighter of minor mode
  (setq doom-modeline--flymake-text
        (let* ((known (hash-table-keys flymake--backend-state))
               (running (flymake-running-backends))
               (disabled (flymake-disabled-backends))
               (reported (flymake-reporting-backends))
               (diags-by-type (make-hash-table))
               (all-disabled (and disabled (null running)))
               (some-waiting (cl-set-difference running reported)))
          (maphash (lambda (_b state)
                     (mapc (lambda (diag)
                             (push diag
                                   (gethash (flymake--diag-type diag)
                                            diags-by-type)))
                           (flymake--backend-state-diags state)))
                   flymake--backend-state)
          (let ((.error (length (gethash :error diags-by-type)))
                (.warning (length (gethash :warning diags-by-type)))
                (.note (length (gethash :note diags-by-type))))
            (propertize
             (cond
              (some-waiting "Running..." "")
              ((null known) (doom-modeline-checker-text "-" 'font-lock-doc-face))
              (all-disabled (doom-modeline-checker-text "-" 'doom-modeline-urgent))
              (t (if (> (+ .error .warning .note) 0)
                     (format "%s/%s/%s"
                             (doom-modeline-checker-text (number-to-string .error)
                                                         'doom-modeline-urgent)
                             (doom-modeline-checker-text (number-to-string .warning)
                                                         'doom-modeline-warning)
                             (doom-modeline-checker-text (number-to-string .note)
                                                         'doom-modeline-info))
                   ""))))))))
(advice-add #'flymake--handle-report :after #'doom-modeline-update-flymake-text)

(doom-modeline-def-segment checker
  "Displays color-coded error status in the current buffer with pretty
icons."
  (let ((active (doom-modeline--active))
        (seg (cond ((and (bound-and-true-p flymake-mode)
                         (bound-and-true-p flymake--backend-state)) ; only support 26+
                    `(,doom-modeline--flymake-icon . ,doom-modeline--flymake-text))
                   ((bound-and-true-p flycheck-mode)
                    `(,doom-modeline--flycheck-icon . ,doom-modeline--flycheck-text)))))
    (when-let ((icon (car seg))
               (text (cdr seg)))
      (concat
       (if vc-mode " " "  ")
       (if active
           (concat icon text)
         (concat
          (propertize icon 'face 'mode-line-inactive)
          (propertize text 'face 'mode-line-inactive))) "  "))))

;;
;; selection-info
;;

(defsubst doom-modeline-column (pos)
  "Get the column of the position `POS'."
  (save-excursion (goto-char pos)
                  (current-column)))

(defvar-local doom-modeline-enable-word-count nil
  "If non-nil, a word count will be added to the selection-info modeline
segment.")

(doom-modeline-def-segment selection-info
  "Information about the current selection, such as how many characters and
lines are selected, or the NxM dimensions of a block selection."
  (when (and mark-active  (doom-modeline--active))
    (cl-destructuring-bind (beg . end)
        (cons (region-beginning) (region-end))
      (propertize
       (let ((lines (count-lines beg (min end (point-max)))))
         (concat (cond ((bound-and-true-p rectangle-mark-mode)
                        (let ((cols (abs (- (doom-modeline-column end)
                                            (doom-modeline-column beg)))))
                          (format "%dx%dB" lines cols)))
                       ((> lines 1)
                        (format "%dC %dL" (- end beg) lines))
                       ((format "%dC" (- end beg))))
                 (when doom-modeline-enable-word-count
                   (format " %dW" (count-words beg end)))))
       'face 'doom-modeline-highlight))))


;;
;; matches (anzu, iedit)
;;

(defsubst doom-modeline--anzu ()
  "Show the match index and total number thereof.

Requires `anzu'."
  (setq anzu-cons-mode-line-p nil)
  (when (and (bound-and-true-p anzu--state)
             (not (bound-and-true-p iedit-mode)))
    (propertize
     (let ((here anzu--current-position)
           (total anzu--total-matched))
       (cond ((eq anzu--state 'replace-query)
              (format " %d replace " total))
             ((eq anzu--state 'replace)
              (format " %d/%d " here total))
             (anzu--overflow-p
              (format " %s+ " total))
             (t
              (format " %s/%d " here total))))
     'face (if (doom-modeline--active) 'doom-modeline-panel))))


(defsubst doom-modeline--multiple-cursors ()
  "Show the number of multiple cursors."
  (when (bound-and-true-p multiple-cursors-mode)
    (propertize
     (concat (car mc/mode-line)
             (eval (cadadr mc/mode-line))
             " ")
     'face (if (doom-modeline--active) 'doom-modeline-panel))))

(doom-modeline-def-segment matches
  "Displays: A current/total for the current search term (with `anzu'),
The number of active `multiple-cursors'."
  (let ((meta (concat (doom-modeline--anzu)
                      (doom-modeline--multiple-cursors))))
    (or (and (not (equal meta "")) meta)
        (if (and buffer-file-name size-indication-mode)
            (propertize " %I ")))))


;;
;; media-info
;;

(doom-modeline-def-segment media-info
  "Metadata regarding the current file, such as dimensions for images."
  ;; TODO Include other information
  (cond ((eq major-mode 'image-mode)
         (cl-destructuring-bind (width . height)
             (when (fboundp 'image-size)
               (image-size (image-get-display-property) :pixels))
           (format "  %dx%d  " width height)))))


;;
;; bar
;;

(defvar doom-modeline--bar-active nil)
(defvar doom-modeline--bar-inactive nil)
(doom-modeline-def-segment bar
  "The bar regulates the height of the mode-line in GUI Emacs.
Returns \"\" to not break --no-window-system."
  (if (display-graphic-p)
      (if (doom-modeline--active)
          doom-modeline--bar-active
        doom-modeline--bar-inactive)
    ""))

(when (>= emacs-major-version 26)
  (add-variable-watcher
   'doom-modeline-height
   (lambda (_sym val op _where)
     (when (and (eq op 'set) (integerp val))
       (doom-modeline-refresh-bars doom-modeline-bar-width val))))

  (add-variable-watcher
   'doom-modeline-bar-width
   (lambda (_sym val op _where)
     (when (and (eq op 'set) (integerp val))
       (doom-modeline-refresh-bars val doom-modeline-height)))))

(add-hook 'after-setting-font-hook
          '(lambda ()
             (doom-modeline-refresh-bars)))


;;
;; window number
;;

(doom-modeline-def-segment window-number
  (let ((num (cond
              ((bound-and-true-p ace-window-display-mode)
               (setq mode-line-format
                     (assq-delete-all 'ace-window-display-mode
                                      (default-value 'mode-line-format)))
               (setq-default mode-line-format mode-line-format)
               (window-parameter (selected-window) 'ace-window-path))
              (t ""))))
    (if (< 0 (length num))
        (propertize (format " %s " num)
                    'face (if (doom-modeline--active)
                              'doom-modeline-buffer-major-mode))
      "")))


;;
;; workspace number
;;

(doom-modeline-def-segment workspace-number
  "The current workspace name or number.
Requires `eyebrowse-mode' to be enabled."
  (if (and (bound-and-true-p eyebrowse-mode)
           (< 1 (length (eyebrowse--get 'window-configs))))
      (let* ((num (eyebrowse--get 'current-slot))
             (tag (when num (nth 2 (assoc num (eyebrowse--get 'window-configs)))))
             (str (if (and tag (< 0 (length tag)))
                      tag
                    (when num (int-to-string num)))))
        (propertize (format " %s " str) 'face
                    (if (doom-modeline--active) 'doom-modeline-buffer-major-mode)))
    ""))


;;
;; perspective name
;;

(defvar-local doom-modeline--persp-name nil)
(defun doom-modeline-update-persp-name (&rest _)
  "Update perspective name in mode-line."
  (setq doom-modeline--persp-name
        ;; Support `persp-mode', while not support `perspective'
        (when (and doom-modeline-persp-name
                   (bound-and-true-p persp-mode)
                   (fboundp 'safe-persp-name)
                   (fboundp 'get-current-persp))
          (let ((persp (get-current-persp)))
            (propertize
             (format " #%s " (safe-persp-name persp))
             'face (if (and persp
                            (not (persp-contain-buffer-p (current-buffer) persp)))
                       'doom-modeline-persp-buffer-not-in-persp
                     'doom-modeline-persp-name))))))

(add-hook 'find-file-hook #'doom-modeline-update-persp-name)
(add-hook 'after-revert-hook #'doom-modeline-update-persp-name)
(add-hook 'persp-activated-functions #'doom-modeline-update-persp-name)
(add-hook 'persp-renamed-functions #'doom-modeline-update-persp-name)
(advice-add #'select-window :after #'doom-modeline-update-persp-name)
;; (advice-add #'persp-add-buffer :after #'doom-modeline-update-persp-name)
;; (advice-add #'persp-remove-buffer :after #'doom-modeline-update-persp-name)

(doom-modeline-def-segment persp-name
  "The current perspective name."
  (if (doom-modeline--active)
      doom-modeline--persp-name
    ""))


;;
;; global
;;

(doom-modeline-def-segment global
  "For the time string and whatever uses global-mode-string."
  (if (and (doom-modeline--active)
           (< 0 (length global-mode-string)))
      '("" global-mode-string " ")
    ""))


;;
;; position
;;

;; Be compatible with Emacs 25.
(defvar doom-modeline-column-zero-based
  (if (boundp 'column-number-indicator-zero-based)
      column-number-indicator-zero-based
    t)
  "When non-nil, mode line displays column numbers zero-based.
See `column-number-indicator-zero-based'.")

(defvar doom-modeline-percent-position
  (if (boundp 'mode-line-percent-position)
      mode-line-percent-position
    '(-3 "%p"))
  "Specification of \"percentage offset\" of window through buffer.
See `mode-line-percent-position'.")

(when (>= emacs-major-version 26)
  (add-variable-watcher
   'column-number-indicator-zero-based
   (lambda (_sym val op _where)
     (when (eq op 'set)
       (setq doom-modeline-column-zero-based val))))

  (add-variable-watcher
   'mode-line-percent-position
   (lambda (_sym val op _where)
     (when (eq op 'set)
       (setq doom-modeline-percent-position val)))))

(setq-default mode-line-position
              '((line-number-mode
                 (column-number-mode
                  (doom-modeline-column-zero-based " %l:%c" " %l:%C")
                  " %l")
                 (column-number-mode (doom-modeline-column-zero-based " :%c" " :%C")))
                (if doom-modeline-percent-position (" " doom-modeline-percent-position))
                (:eval (when (or line-number-mode column-number-mode doom-modeline-percent-position) " "))))

(doom-modeline-def-segment buffer-position
  "The buffer position information."
  `(:propertize (concat " " mode-line-position)))

;;
;; input method
;;

(doom-modeline-def-segment input-method
  "The current input method."
  (when (doom-modeline--active)
    (propertize
     (cond
      (current-input-method
       (concat " " current-input-method-title))
      (t ""))
     'face 'doom-modeline-buffer-major-mode)))

;;
;; LSP
;;

(doom-modeline-def-segment lsp
  "The LSP server state."
  (if (and doom-modeline-lsp
           (doom-modeline--active)
           (bound-and-true-p lsp-mode))
      (concat (lsp-mode-line) " ")))

;;
;; Mode lines
;;

(doom-modeline-def-modeline 'main
  '(bar workspace-number window-number  matches " " buffer-info remote-host buffer-position " " selection-info)
  '(global persp-name lsp minor-modes input-method buffer-encoding major-mode process vcs checker))

(doom-modeline-def-modeline 'minimal
  '(bar matches " " buffer-info)
  '(media-info major-mode))

;;
;; Hooks
;;

(defun doom-modeline-refresh-bars (&optional width height)
  "Refresh mode-line bars with `WIDTH' and `HEIGHT'."
  (setq doom-modeline--bar-active
        (doom-modeline--make-xpm 'doom-modeline-bar
                                 (or width doom-modeline-bar-width)
                                 (max (or height doom-modeline-height)
                                      (frame-char-height)))
        doom-modeline--bar-inactive
        (doom-modeline--make-xpm 'doom-modeline-inactive-bar
                                 (or width doom-modeline-bar-width)
                                 (max (or height doom-modeline-height)
                                      (frame-char-height)))))

;;;###autoload
(defun doom-modeline-init ()
  "Initialize doom mode-line."
  ;; Create bars
  (doom-modeline-refresh-bars)
  (unless after-init-time
    ;; These buffers are already created and don't get modelines. For the love
    ;; of Emacs, someone give the man a modeline!
    (dolist (bname '("*scratch*" "*Messages*"))
      (with-current-buffer bname
        (doom-modeline-set-modeline 'main)))))

;;;###autoload
(defun doom-modeline-set-minimal-modeline ()
  "Set sepcial mode-line."
  (doom-modeline-set-modeline 'minimal))

;;;###autoload
(defun doom-modeline-set-special-modeline ()
  "Set sepcial mode-line."
  (doom-modeline-set-modeline 'special))

;;;###autoload
(defun doom-modeline-set-media-modeline ()
  "Set media mode-line."
  (doom-modeline-set-modeline 'media))

;;;###autoload
(defun doom-modeline-set-project-modeline ()
  "Set project mode-line."
  (doom-modeline-set-modeline 'project))

;;
;; Bootstrap
;;

(doom-modeline-set-modeline 'main t) ; set default modeline

(add-hook 'image-mode-hook #'doom-modeline-set-media-modeline)
(add-hook 'org-src-mode-hook #'doom-modeline-set-special-modeline)
(add-hook 'circe-mode-hook #'doom-modeline-set-special-modeline)


;; Ensure modeline is inactive when Emacs is unfocused (and active otherwise)
(defvar doom-modeline-remap-face-cookie nil)
(defun doom-modeline-focus ()
  "Focus mode-line."
  (when doom-modeline-remap-face-cookie
    (require 'face-remap)
    (face-remap-remove-relative doom-modeline-remap-face-cookie)))
(defun doom-modeline-unfocus ()
  "Unfocus mode-line."
  (setq doom-modeline-remap-face-cookie (face-remap-add-relative 'mode-line 'mode-line-inactive)))

(with-no-warnings
  (if (boundp 'after-focus-change-function)
      (progn
        (defun doom-modeline-focus-change ()
          (if (frame-focus-state)
              (doom-modeline-focus)
            (doom-modeline-unfocus)))
        (add-function :after after-focus-change-function #'doom-modeline-focus-change))
    (progn
      (add-hook 'focus-in-hook #'doom-modeline-focus)
      (add-hook 'focus-out-hook #'doom-modeline-unfocus))))

(provide 'doom-modeline)

;;; doom-modeline.el ends here
