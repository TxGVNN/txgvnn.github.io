;;; ace-jump-mode-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "ace-jump-mode" "ace-jump-mode.el" (0 0 0 0))
;;; Generated autoloads from ace-jump-mode.el

(autoload 'ace-jump-mode-pop-mark "ace-jump-mode" "\
Pop up a postion from `ace-jump-mode-mark-ring', and jump back to that position\n\n(fn)" t nil)

(autoload 'ace-jump-char-mode "ace-jump-mode" "\
AceJump char mode\n\n(fn QUERY-CHAR)" t nil)

(autoload 'ace-jump-word-mode "ace-jump-mode" "\
AceJump word mode.\nYou can set `ace-jump-word-mode-use-query-char' to nil to prevent\nasking for a head char, that will mark all the word in current\nbuffer.\n\n(fn HEAD-CHAR)" t nil)

(autoload 'ace-jump-line-mode "ace-jump-mode" "\
AceJump line mode.\nMarked each no empty line and move there\n\n(fn)" t nil)

(autoload 'ace-jump-mode "ace-jump-mode" "\
AceJump mode is a minor mode for you to quick jump to a\nposition in the curret view.\n   There is three submode now:\n     `ace-jump-char-mode'\n     `ace-jump-word-mode'\n     `ace-jump-line-mode'\n\nYou can specify the sequence about which mode should enter\nby customize `ace-jump-mode-submode-list'.\n\nIf you do not want to query char for word mode, you can change\n`ace-jump-word-mode-use-query-char' to nil.\n\nIf you don't like the default move keys, you can change it by\nsetting `ace-jump-mode-move-keys'.\n\nYou can constrol whether use the case sensitive via\n`ace-jump-mode-case-fold'.\n\n(fn &optional PREFIX)" t nil)

(if (fboundp 'register-definition-prefixes) (register-definition-prefixes "ace-jump-mode" '("aj-" "ace-jump-")))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; ace-jump-mode-autoloads.el ends here
