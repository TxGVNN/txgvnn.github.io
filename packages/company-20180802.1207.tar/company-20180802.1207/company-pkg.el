(define-package "company" "20180802.1207" "Modular text completion framework"
  '((emacs "24.3"))
  :keywords
  '("abbrev" "convenience" "matching")
  :authors
  '(("Nikolaj Schumacher"))
  :maintainer
  '("Dmitry Gutov" . "dgutov@yandex.ru")
  :url "http://company-mode.github.io/")
;; Local Variables:
;; no-byte-compile: t
;; End:
