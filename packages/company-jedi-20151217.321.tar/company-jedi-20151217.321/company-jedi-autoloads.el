;;; company-jedi-autoloads.el --- automatically extracted autoloads
;;
;;; Code:

(add-to-list 'load-path (directory-file-name
                         (or (file-name-directory #$) (car load-path))))


;;;### (autoloads nil "company-jedi" "company-jedi.el" (0 0 0 0))
;;; Generated autoloads from company-jedi.el

(autoload 'company-jedi "company-jedi" "\
`company-mode' completion back-end for `jedi-code.el'.\nProvide completion info according to COMMAND and ARG.  IGNORED, not used.\n\n(fn COMMAND &optional ARG &rest IGNORED)" t nil)

(if (fboundp 'register-definition-prefixes) (register-definition-prefixes "company-jedi" '("company-jedi-")))

;;;***

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; company-jedi-autoloads.el ends here
