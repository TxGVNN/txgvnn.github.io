(define-package "php-mode" "20181206.825" "Major mode for editing PHP code"
  '((emacs "24.3")
    (cl-lib "0.5"))
  :keywords
  '("languages" "php")
  :authors
  '(("Eric James Michael Ritz"))
  :maintainer
  '("USAMI Kenta" . "tadsan@zonu.me")
  :url "https://github.com/emacs-php/php-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
