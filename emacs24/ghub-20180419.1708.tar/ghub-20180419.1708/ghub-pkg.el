(define-package "ghub" "20180419.1708" "minuscule client library for the Github API"
  '((emacs "24.4")
    (let-alist "1.0.5"))
  :keywords
  '("tools")
  :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :url "https://github.com/magit/ghub")
;; Local Variables:
;; no-byte-compile: t
;; End:
